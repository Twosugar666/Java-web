package com.twosugar.util;

public class Constants {
    public final static String USER_SESSION = "userSession";
    public final static int pageSize = 8;
}
