package com.twosugar.service.Role;

import com.twosugar.dao.BaseDao;
import com.twosugar.dao.role.RoleDao;
import com.twosugar.dao.role.RoleDaoImpl;
import com.twosugar.pojo.Role;

import java.sql.Connection;
import java.util.List;


public class RoleServiceImpl implements RoleService{

    private RoleDao roleDao;

    public RoleServiceImpl(){
        roleDao = new RoleDaoImpl();
    }

    @Override
    public List<Role> getRoleList() {
        Connection connection = null;
        List<Role> roleList = null;
        try {
            connection = BaseDao.getConnection();
            roleList = roleDao.getRoleList(connection);
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            BaseDao.closeResource(connection, null, null);
        }
        return roleList;
    }

}